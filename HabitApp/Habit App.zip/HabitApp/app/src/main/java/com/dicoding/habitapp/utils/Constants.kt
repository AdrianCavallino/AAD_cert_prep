package com.dicoding.habitapp.utils

const val HABIT = "HABIT"
const val HABIT_ID = "HABIT_ID"
const val HABIT_TITLE = "HABIT_TITLE"
const val HABIT_MINUTE_FOCUS = "HABIT_MINUTE_FOCUS"
const val HABIT_START_TIME = "HABIT_START_TIME"
const val HABIT_LEVEL = "HABIT_LEVEL"
const val NOTIFICATION_CHANNEL_ID = "notify-channel"
const val NOTIF_UNIQUE_WORK: String = "NOTIF_UNIQUE_WORK"

